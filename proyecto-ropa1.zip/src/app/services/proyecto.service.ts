import { Injectable, inject } from '@angular/core';
import { Firestore, collection, collectionData, addDoc, doc, deleteDoc, updateDoc } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Proyecto } from '../interfaces/proyecto.interface';

@Injectable({ providedIn: 'root' })

export class ProyectosService {
  private firestore: Firestore = inject(Firestore);

// Obtiene todos los proyectos como un Observable que se actualiza en tiempo real
  getProyectos(): Observable<Proyecto[]> {
    const proyectosRef = collection(this.firestore, 'proyectos');
    return collectionData(proyectosRef, { idField: 'id' }) as Observable<Proyecto[]>;
  }

// Crea un nuevo documento en la colección 'proyectos'
  async crearProyecto(proyecto: Proyecto): Promise<void> {
    const proyectosRef = collection(this.firestore, 'proyectos');
    await addDoc(proyectosRef, proyecto);
  }

// Actualiza un documento existente por ID con solo los campos modificados
  async actualizarProyecto(id: string, cambios: Partial<Proyecto>): Promise<void> {
    const docRef = doc(this.firestore, `proyectos/${id}`);
    await updateDoc(docRef, cambios);
  }

// Elimina un documento de la colección por su ID
  async eliminarProyecto(id: string): Promise<void> {
    const docRef = doc(this.firestore, `proyectos/${id}`);
    await deleteDoc(docRef);
  }
}