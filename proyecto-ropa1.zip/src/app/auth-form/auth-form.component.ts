import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { FormsModule } from '@angular/forms'; 

// Funciones y tipos de autenticación de Firebase
import {
  Auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User,
} from '@angular/fire/auth';

// Para navegar entre páginas de Angular
import { Router } from '@angular/router';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-auth-form', 
  standalone: true, // Indica que este componente no necesita un módulo para declararse
  imports: [CommonModule, FormsModule, ToastModule], // Importaciones necesarias para que funcione el HTML y los toasts
  templateUrl: './auth-form.component.html', 
  styleUrl: './auth-form.component.scss', 
})
export class AuthFormComponent implements OnInit {
  // Inyectamos las dependencias necesarias
  auth = inject(Auth); // Servicio de autenticación de Firebase
  router = inject(Router); // Servicio de rutas
  messageService = inject(MessageService); // Servicio para mostrar notificaciones tipo toast

  // Variables para los campos del formulario
  email = '';
  password = '';
  isLogin = true; // Determina si el formulario está en modo login o registro

  // Signal para almacenar el usuario autenticado y reaccionar a sus cambios
  user = signal<User | null>(null);

  // Hook que se ejecuta al inicializar el componente
  ngOnInit() {
    // Escucha cambios en el estado de autenticación
    onAuthStateChanged(this.auth, (user) => {
      this.user.set(user); // Actualiza el signal con el usuario actual
    });
  }

  // Cambia entre el modo de login y el de registro
  toggleMode() {
    this.isLogin = !this.isLogin;
  }

  // Función que se ejecuta al enviar el formulario
  async onSubmit() {
    try {
      if (this.isLogin) {
        // Si está en modo login, intenta iniciar sesión
        await signInWithEmailAndPassword(this.auth, this.email, this.password);
        // Muestra un toast de éxito
        this.messageService.add({
          severity: 'success',
          summary: 'Bienvenido ',
          detail: 'Sesión iniciada correctamente',
        });
      } else {
        // Si está en modo registro, crea una nueva cuenta
        await createUserWithEmailAndPassword(this.auth, this.email, this.password);
        // Muestra un toast de éxito
        this.messageService.add({
          severity: 'success',
          summary: 'Registrado',
          detail: 'Cuenta creada correctamente',
        });
      }
      // Redirige al usuario a la página de inicio
      this.router.navigate(['../paginas/inicio']);
    } catch (error: any) {
      // Si hay error, muestra un toast con el mensaje de error
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: "Llene los campos correctamente",
      });
    }
  }

  // Función para cerrar sesión
  async logout() {
    await signOut(this.auth); // Cierra sesión con Firebase
    // Muestra un toast informativo
    this.messageService.add({
      severity: 'info',
      summary: 'Cierre de sesión',
      detail: 'Sesión cerrada correctamente',
    });
  }
}
