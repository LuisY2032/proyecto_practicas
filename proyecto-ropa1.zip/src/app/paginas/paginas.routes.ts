import { AsignacionProductosComponent } from "./asignacion-productos/asignacion-productos.component";
import { InicioComponent } from "./inicio/inicio.component";
import { ProductosComponent } from "./productos/productos.component";
import { ProyectosComponent } from "./proyectos/proyectos.component";
import { MainComponent } from "../layout/main/main.component";
import { Routes } from "@angular/router";


export default [
    {
        path: '',
        component: MainComponent,
        children: [
            {
                path: 'inicio',
                component: InicioComponent,
                title: 'Inicio'
            },
            {
                path: 'productos',
                component: ProductosComponent,
                title: 'Productos'
            },
            {
                path: 'proyectos',
                component: ProyectosComponent,
                title: 'Proyectos'
            },
            {
                path: 'asignacion',
                component: AsignacionProductosComponent,
                title: 'Asignacion'
            },
            {
                path: '', 
                redirectTo: 'inicio', 
                pathMatch: 'full'
            }
    ]
}
] satisfies Routes;


