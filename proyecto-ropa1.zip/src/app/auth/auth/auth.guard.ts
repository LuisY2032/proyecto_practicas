import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Auth } from '@angular/fire/auth';
import { onAuthStateChanged } from 'firebase/auth';
import { firstValueFrom, from } from 'rxjs';

// Guard de ruta que controla el acceso basado en la autenticación del usuario
export const authGuard: CanActivateFn = async () => {
  // Inyecta el servicio de autenticación de Firebase
  const auth = inject(Auth);
  // Inyecta el servicio de enrutamiento para redirigir si no está autenticado
  const router = inject(Router);

  // Espera a que cambie el estado de autenticación y obtiene el usuario actual
  const user = await firstValueFrom(from(
    // Se crea una promesa que se resuelve cuando onAuthStateChanged detecta un cambio
    new Promise(resolve => onAuthStateChanged(auth, resolve))
  ));

  // Si no hay usuario autenticado, redirige a la página de login y bloquea la ruta
  if (!user) {
    router.navigate(['/login']);
    return false;
  }

  // Si hay usuario autenticado, permite el acceso a la ruta
  return true;
};

