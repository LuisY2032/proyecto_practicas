// Interfaz que define la estructura de un material, con nombre y un código único
export interface Material {
  name: string;  // Nombre del material (por ejemplo: "Algodón", "Cuero")
  code: string;  // Código del material (por ejemplo: "MAT001")
}

// Interfaz que define los géneros (posiblemente para ropa), con nombre y código
export interface Generos {
  name: string;  // Nombre del género (por ejemplo: "Masculino", "Femenino")
  code: string;  // Código del género (por ejemplo: "GEN001")
}

// Interfaz principal para representar un producto
export interface Producto {
  id?: string;  // ID único del producto (opcional)
  nombre?: string;  // Nombre del producto (opcional)

  // Puede ser un objeto Material o simplemente un string que represente el material (flexibilidad para guardar solo el código/nombre si se desea)
  material?: Material | string;

  // Puede ser un arreglo de objetos Generos o un arreglo de strings, útil para representar varios géneros relacionados (ej: ["Masculino", "Unisex"])
  generos?: Generos[] | string[];

  precio?: number;  // Precio del producto (opcional)
  categoria?: string;  // Categoría del producto (ej: "Camisas", "Accesorios") (opcional)
  cantidad?: number;  // Stock disponible (opcional)
  valoracion: number;  // Valoración promedio del producto (número obligatorio)
  disponible: boolean;  // Indica si el producto está disponible o no (booleano obligatorio)
  descripcion?: string;  // Descripción del producto (opcional)
  fechaLanzamiento?: Date;  // Fecha en que fue lanzado el producto (opcional)
}
