import { Component, inject, OnInit, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { MenubarModule } from 'primeng/menubar';
import { CommonModule } from '@angular/common';
import { Router, RouterModule} from '@angular/router';
import { Auth, signOut, User, onAuthStateChanged } from '@angular/fire/auth';

// Decorador que define el componente
@Component({
  selector: 'app-topbar',                                 // Selector usado en el HTML para este componente
  imports: [CommonModule, RouterModule, MenubarModule],   // Módulos necesarios para el funcionamiento del componente
  templateUrl: './topbar.component.html',                 
  styleUrl: './topbar.component.scss'                     
})
export class TopbarComponent implements OnInit {

  items: MenuItem[] = []; // Lista de elementos del menú superior

  // Inyección de dependencias
  auth = inject(Auth);        // Servicio de autenticación
  router = inject(Router);    // Servicio de enrutamiento
  user = signal<User | null>(null); // Estado reactivo que almacena el usuario actual (o null si no está autenticado)

  // Método que se ejecuta al inicializar el componente
  ngOnInit() {
    // Definición de los ítems del menú de navegación
    this.items = [
      {
        label: 'Inicio',
        icon: 'pi pi-home',                  
        routerLink: '/paginas/inicio'        
      },
      {
        label: 'Productos',
        icon: 'pi pi-shopping-bag',
        routerLink: '/paginas/productos'
      },
      {
        label: 'Proyectos',
        icon: 'pi pi-pen-to-square',
        routerLink: '/paginas/proyectos'
      },
      {
        label: 'Destinatario',
        icon: 'pi pi-folder-open',
        routerLink: '/paginas/asignacion'
      },
    ];

    // Escucha cambios en el estado de autenticación y actualiza el estado 'user'
    onAuthStateChanged(this.auth, (usuario) => {
      this.user.set(usuario); // Actualiza el estado con el usuario autenticado
    });
  }

  // Método para cerrar sesión del usuario
  async logout() {
    await signOut(this.auth);         // Cierra la sesión
    this.router.navigate(['/login']); // Redirige al login
  }

  // Método que retorna si hay un usuario autenticado
  isAuthenticated() {
    return this.user() !== null;
  }

}
