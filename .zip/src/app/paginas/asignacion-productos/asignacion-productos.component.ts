// asignacion-productos.component.ts
import { Component, inject } from '@angular/core';
import { Firestore} from '@angular/fire/firestore';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputNumberModule } from 'primeng/inputnumber';
import { CardModule } from 'primeng/card';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Proyecto, ProductoAsignado} from '../../interfaces/proyecto.interface';
import { Producto } from '../../interfaces/producto.interface';
import { AsignacionService } from '../../services/asignacion.service';

@Component({
  selector: 'app-asignacion-productos', 
  standalone: true,                     
  imports: [                            
    DropdownModule, CommonModule, FormsModule, 
    TableModule, ButtonModule, InputNumberModule, CardModule
  ],
  templateUrl: './asignacion-productos.component.html', 
  styleUrl: './asignacion-productos.component.scss'      
})
export class AsignacionProductosComponent {

  // Inyección de Firestore directamente 
  private firestore: Firestore = inject(Firestore);

  // Listado de proyectos y productos cargados desde Firebase
  proyectos: Proyecto[] = [];
  productos: Producto[] = [];

  // Proyecto seleccionado por el usuario
  proyectoSeleccionado: Proyecto | null = null;

  // Productos actualmente asignados al proyecto seleccionado
  productosSeleccionados: ProductoAsignado[] = [];

  // Datos del producto que se va a agregar
  productoParaAgregar: {
    producto: Producto | null;
    cantidad: number;
    precioUnitario: number;
  } = {
    producto: null,
    cantidad: 1,
    precioUnitario: 0
  };

  // Constructor: inyecta el servicio de asignación y carga los datos
  constructor(private asignacionService: AsignacionService) {
    this.cargarDatos();
  }

  // Método para obtener los proyectos y productos desde el servicio (base de datos)
  cargarDatos(): void {
    this.asignacionService.getProyectos().subscribe(data => {
      this.proyectos = data; // Lista de proyectos desde Firestore
    });
    this.asignacionService.getProductos().subscribe(data => {
      this.productos = data; // Lista de productos desde Firestore
    });
  }

  // Se ejecuta al seleccionar un proyecto: carga los productos asignados a ese proyecto
  seleccionarProyecto(proyecto: Proyecto) {
    if (proyecto) {
      this.proyectoSeleccionado = proyecto;
      this.productosSeleccionados = proyecto.productosAsignados ?? []; // Si no tiene, lista vacía
    }
  }

  // Agrega un producto a la lista del proyecto con cantidad y precio unitario
  agregarProducto() {
    const { producto, cantidad, precioUnitario } = this.productoParaAgregar;

    if (!producto) return; // Si no hay producto seleccionado, no hace nada

    const nuevoProducto: ProductoAsignado = {
      ...producto,                  // Copia las propiedades del producto base
      cantidad,
      precioUnitario,
      total: cantidad * precioUnitario // Calcula el total por ese producto
    };

    this.productosSeleccionados.push(nuevoProducto); // Agrega el producto a la lista
    this.actualizarProyecto();                       // Guarda los cambios en Firestore
    this.productoParaAgregar = { producto: null, cantidad: 1, precioUnitario: 0 }; // Limpia campos
  }

  // Elimina un producto de la lista según su índice
  eliminarProducto(index: number) {
    if (index >= 0 && index < this.productosSeleccionados.length) {
      this.productosSeleccionados.splice(index, 1); // Elimina el producto
      this.actualizarProyecto();                    // Actualiza el proyecto en Firestore
    }
  }

  // Actualiza el documento del proyecto en Firestore con la nueva lista de productos asignados
  async actualizarProyecto(): Promise<void> {
    if (!this.proyectoSeleccionado) return;
    await this.asignacionService.actualizarProyecto(
      this.proyectoSeleccionado?.id || '',
      { productosAsignados: this.productosSeleccionados }
    );
  }

  // Calcula el total general sumando el total de cada producto asignado
  calcularTotal(): number {
    return this.productosSeleccionados.reduce((sum, item) => sum + item.total, 0);
  }
}
