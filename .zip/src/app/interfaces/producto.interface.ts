// Interfaz que define la estructura de un material, con nombre y un código único
export interface Material {
  name: string;  
  code: string;  
}

// Interfaz que define los géneros para ropa, con nombre y código
export interface Generos {
  name: string;  
  code: string;  
}

// Interfaz principal para representar un producto
export interface Producto {
  id?: string;  
  nombre?: string;  

  // Puede ser un objeto Material o simplemente un string que represente el material (flexibilidad para guardar solo el código/nombre si se desea)
  material?: Material | string;

  // Puede ser un arreglo de objetos Generos o un arreglo de strings, útil para representar varios géneros
  generos?: Generos[] | string[];

  precio?: number;  
  categoria?: string;  
  cantidad?: number;  
  valoracion: number;  
  disponible: boolean;  // Indica si el producto está disponible o no (booleano obligatorio)
  descripcion?: string;  
  fechaLanzamiento?: Date;  // Fecha en que fue comprado el producto (opcional)
}
